Conversion to a textual format.

The text format is currently very ad-hoc and there is no conversion back, but
it's a pleasant way to view the IR.
